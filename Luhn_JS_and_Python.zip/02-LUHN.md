## Luhn Algorithm, now in Javascript!

Look up the Luhn algorithm your wrote in week 1 of phase 1. This was the problem
that validated a credit card.

Create an `<input>` field and an empty div. Use the onChange event on the
`<input>` to have the div's content say either 'Invalid Card' or 'Valid VISA' (etc.)
as the user inputs text into the input field.
